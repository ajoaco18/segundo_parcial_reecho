package servicio;

public interface CSVFactory<T> {
    T fromCSV(String csv);
}
