package servicio;

import servicio.CSVSerializable;
import java.io.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;
import modelo.Libro;

public class Inventario<T extends CSVSerializable & Serializable> implements Serializable {
    private static final long serialVersionUID = 1L;

    private final List<T> elementos;

    public Inventario() {
        this.elementos = new ArrayList<>();
    }

    public void agregar(T elemento) {
        if (elemento == null) {
            throw new IllegalArgumentException("El elemento no puede ser nulo.");
        }
        elementos.add(elemento);
    }

    public T obtener(int indice) {
        if (indice < 0 || indice >= elementos.size()) {
            throw new IndexOutOfBoundsException("Índice fuera de rango.");
        }
        return elementos.get(indice);
    }

    public void eliminar(int indice) {
        if (indice < 0 || indice >= elementos.size()) {
            throw new IndexOutOfBoundsException("Índice fuera de rango.");
        }
        elementos.remove(indice);
    }
    
    public List<T> filtrar(Predicate<T> criterio) {
    List<T> resultado = new ArrayList<>();
    for (T elemento : elementos) {
        if (criterio.test(elemento)) {
            resultado.add(elemento);
        }
    }
    return resultado;
}
    

    public void ordenar() {
        elementos.sort(null); // Usa el orden natural
    }

    public void ordenar(Comparator<T> comparador) {
        elementos.sort(comparador);
    }

    public void guardarEnArchivo(String ruta) throws IOException {
    File archivo = new File(ruta);
    if (archivo.getParentFile() != null && !archivo.getParentFile().exists()) {
        throw new IOException("El directorio no existe: " + archivo.getParent());
    }
    try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(archivo))) {
        salida.writeObject(this);
    }
}


    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(ruta))) {
            Inventario<T> inventarioCargado = (Inventario<T>) input.readObject();
            this.elementos.clear();
            this.elementos.addAll(inventarioCargado.elementos);
        }
    }

    public void guardarEnCSV(String ruta) throws IOException {
    File archivo = new File(ruta);
    if (archivo.getParentFile() != null && !archivo.getParentFile().exists()) {
        throw new IOException("El directorio no existe: " + archivo.getParent());
    }
    try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {
        for (T elemento : elementos) {
            bw.write(elemento.toCSV());
            bw.newLine();
        }
    }
}
    

    public static List<Libro> cargarDesdeCSV(String ruta, CSVFactory<Libro> factory) throws IOException {
    List<Libro> libros = new ArrayList<>();
    try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
        String linea;
        while ((linea = br.readLine()) != null) {
            libros.add(factory.fromCSV(linea));
        }
    }
    return libros;
}

    public void paraCadaElemento(Consumer<T> accion) {
        if (accion == null) {
            throw new IllegalArgumentException("La acción no puede ser nula.");
        }
        for (T elemento : elementos) {
            accion.accept(elemento);
        }
    }
}