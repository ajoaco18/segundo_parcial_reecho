package main;

import modelo.*;
import servicio.*;

import java.io.IOException;
import java.util.Comparator;

public class Principal {
    public static void main(String[] args) {
        try {
            Inventario<Libro> inventarioLibros = new Inventario<>();
            inventarioLibros.agregar(new Libro(1, "1984", "George Orwell", Categoria.ENTRETENIMIENTO));
            inventarioLibros.agregar(new Libro(2, "El señor de los anillos", "J.R.R. Tolkien", Categoria.LITERATURA));
            inventarioLibros.agregar(new Libro(3, "Cien años de soledad", "Gabriel García Márquez", Categoria.LITERATURA));
            inventarioLibros.agregar(new Libro(4, "El origen de las especies", "Charles Darwin", Categoria.CIENCIA));
            inventarioLibros.agregar(new Libro(5, "La guerra de los mundos", "H.G. Wells", Categoria.ENTRETENIMIENTO));

            // Mostrar todos los libros
            System.out.println("Inventario de libros:");
            inventarioLibros.paraCadaElemento(System.out::println);
            
            // Filtrar por categoría
            System.out.println("\nLibros de la categoría LITERATURA:");
            for (Libro libro : inventarioLibros.filtrar(libro -> libro.getCategoria() == Categoria.LITERATURA)) {
                System.out.println(libro);
            }

            // Filtrar por título
            System.out.println("\nLibros cuyo título contiene '1984':");
            for (Libro libro : inventarioLibros.filtrar(libro -> libro.getTitulo().contains("1984"))) {
                System.out.println(libro);
            }

            // Ordenar por id
            inventarioLibros.ordenar();
            System.out.println("\nLibros ordenados por id:");
            inventarioLibros.paraCadaElemento(System.out::println);

            // Ordenar por título
            inventarioLibros.ordenar(Comparator.comparing(Libro::getTitulo));
            System.out.println("\nLibros ordenados por título:");
            inventarioLibros.paraCadaElemento(System.out::println);

            // Guardar y cargar desde archivo binario
            inventarioLibros.guardarEnArchivo("src/data/libros.dat");
            Inventario<Libro> inventarioCargado = new Inventario<>();
            inventarioCargado.cargarDesdeArchivo("src/data/libros.dat");
            System.out.println("\nLibros cargados desde archivo binario:");
            inventarioCargado.paraCadaElemento(System.out::println);

            // Guardar y cargar desde archivo CSV
            inventarioLibros.guardarEnCSV("src/data/libros.csv");
            inventarioCargado.cargarDesdeCSV("src/data/libros.csv", Libro::fromCSV);
            System.out.println("\nLibros cargados desde archivo CSV:");
            inventarioCargado.paraCadaElemento(System.out::println);

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
