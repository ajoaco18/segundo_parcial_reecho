package modelo;

import servicio.CSVSerializable;
import java.io.Serializable;

public class Libro implements CSVSerializable, Serializable, Comparable<Libro> {
    private static final long serialVersionUID = 1L;

    private int id;
    private String titulo;
    private String autor;
    private Categoria categoria;

    public Libro(int id, String titulo, String autor, Categoria categoria) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.categoria = categoria;
    }

    // Métodos getter y setter
    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    @Override
    public String toCSV() {
        return id + "," + titulo + "," + autor + "," + categoria;
    }

    public static Libro fromCSV(String csv) {
        String[] campos = csv.split(",");
        int id = Integer.parseInt(campos[0]);
        String titulo = campos[1];
        String autor = campos[2];
        Categoria categoria = Categoria.valueOf(campos[3]);
        return new Libro(id, titulo, autor, categoria);
    }

    @Override
    public String toString() {
        return "Libro{" + "id=" + id + ", titulo='" + titulo + '\'' + ", autor='" + autor + '\'' + ", categoria=" + categoria + '}';
    }

    @Override
    public int compareTo(Libro otro) {
        return Integer.compare(this.id, otro.id); // Compara los libros por su id
    }
}
